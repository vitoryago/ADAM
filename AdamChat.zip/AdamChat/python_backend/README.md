# ADAM Python Backend

This is the core Python backend for ADAM (Advanced Data Analytics Model), providing sophisticated AI capabilities with RAG (Retrieval-Augmented Generation) features.

## Architecture

The ADAM backend is cleanly organized in the `src/adam/` directory with no legacy code from previous versions (adam_v2). It communicates with the Node.js/React frontend via JSON messages over stdin/stdout.

## Key Components

### Core Systems
- **adam_service.py**: Main service orchestrator
- **integrated_conversation_system.py**: Manages conversation flow with LangGraph
- **project_manager.py**: Handles project isolation and memory spaces
- **cost_monitor.py**: Tracks API usage and enforces budget limits

### Memory & RAG
- **advanced_rag.py**: Three-stage retrieval system (BM25, Vector, Graph)
- **memory_network.py**: Graph-based memory connections
- **project_aware_memory.py**: Isolated memory per project
- **temporal_memory_scoring.py**: Time-aware memory relevance

### LLM Integration
- **llm/client.py**: Unified client for OpenAI, Anthropic, and xAI
- **llm/query_analyzer.py**: Complexity detection and model routing
- **llm/config.py**: Model configuration and selection logic

### Additional Features
- **screen_capture.py**: Optional screen analysis for coworker mode
- **activity_tracker.py**: User activity monitoring
- **conversation_aware_memory.py**: Context-aware memory retrieval

## Communication Protocol

The backend communicates via JSON messages:

### Request Format
```json
{
  "type": "QUERY",
  "requestId": "unique-id",
  "data": {
    "query": "user question",
    "projectId": "project-uuid",
    "conversationId": "conversation-uuid",
    "userId": "user-id",
    "context": {}
  }
}
```

### Response Format
```json
{
  "requestId": "unique-id",
  "response": {
    "response": "ADAM's response",
    "cost": 0.0001,
    "modelUsed": "gpt-4o-mini",
    "processingTime": 1234,
    "memoryConfidence": 0.85,
    "sources": [],
    "conversationState": {}
  }
}
```

## Environment Variables

Required API keys:
- `OPENAI_API_KEY`: For GPT models
- `XAI_API_KEY`: For Grok models (optional)
- `ANTHROPIC_API_KEY`: For Claude models (optional)

## Running the Backend

```bash
cd python_backend
python main.py
```

The backend will initialize and wait for JSON messages on stdin.

## No Legacy Code

This implementation contains NO code from adam_v2 or any HTMX components. It's a clean, modern Python backend designed specifically for the React/TypeScript frontend.