"""
Project Manager for ADAM
Manages multiple projects with isolated memory spaces
"""
import json
import os
from typing import Dict, Any, List, Optional
from datetime import datetime
from dataclasses import dataclass, asdict
import uuid

@dataclass
class Project:
    """Project data model"""
    id: str
    name: str
    description: Optional[str] = None
    created_at: str = ""
    updated_at: str = ""
    memory_collection: Optional[str] = None
    conversation_count: int = 0
    total_cost: float = 0.0
    last_accessed: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

class ProjectManager:
    """Manages projects and their isolated memory spaces"""
    
    def __init__(self, config=None):
        self.config = config
        self.projects_file = 'projects.json'
        self.projects = self._load_projects()
        
    def _load_projects(self) -> Dict[str, Project]:
        """Load projects from file"""
        if os.path.exists(self.projects_file):
            try:
                with open(self.projects_file, 'r') as f:
                    data = json.load(f)
                    return {
                        pid: Project(**pdata) 
                        for pid, pdata in data.items()
                    }
            except:
                pass
        return {}
    
    def _save_projects(self):
        """Save projects to file"""
        try:
            data = {
                pid: project.to_dict() 
                for pid, project in self.projects.items()
            }
            with open(self.projects_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving projects: {e}")
    
    async def ensure_project(self, project_id: str, name: Optional[str] = None) -> Project:
        """Ensure a project exists, create if needed"""
        if project_id in self.projects:
            # Update last accessed
            self.projects[project_id].last_accessed = datetime.now().isoformat()
            self._save_projects()
            return self.projects[project_id]
        
        # Create new project
        project = Project(
            id=project_id,
            name=name or f"Project {project_id[:8]}",
            created_at=datetime.now().isoformat(),
            updated_at=datetime.now().isoformat(),
            memory_collection=f"adam_project_{project_id}",
            last_accessed=datetime.now().isoformat()
        )
        
        self.projects[project_id] = project
        self._save_projects()
        return project
    
    async def get_project(self, project_id: str) -> Optional[Project]:
        """Get a project by ID"""
        return self.projects.get(project_id)
    
    async def list_projects(self) -> List[Project]:
        """List all projects"""
        return sorted(
            self.projects.values(),
            key=lambda p: p.last_accessed or p.created_at,
            reverse=True
        )
    
    async def update_project_stats(self, project_id: str, cost: float):
        """Update project statistics"""
        if project_id in self.projects:
            project = self.projects[project_id]
            project.total_cost += cost
            project.updated_at = datetime.now().isoformat()
            project.last_accessed = datetime.now().isoformat()
            self._save_projects()
    
    async def delete_project(self, project_id: str) -> bool:
        """Delete a project"""
        if project_id in self.projects:
            del self.projects[project_id]
            self._save_projects()
            return True
        return False
    
    def get_memory_collection(self, project_id: str) -> str:
        """Get the memory collection name for a project"""
        if project_id in self.projects:
            return self.projects[project_id].memory_collection
        return f"adam_project_{project_id}"