"""
Simplified Integrated Conversation System for ADAM
"""
import asyncio
import time
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class IntegratedConversationSystem:
    """Simplified conversation system for web integration"""
    
    def __init__(self, config=None):
        self.config = config
        self.llm_client = None
        self.memory_system = None
        self.cost_monitor = None
        self.initialized = False
    
    async def initialize(self):
        """Initialize components"""
        if self.initialized:
            return
        
        try:
            # Import components
            from .llm.client import UnifiedLLMClient
            from .memory_system import AdvancedMemorySystem
            from .cost_monitor import CostMonitor
            
            # Initialize components
            self.llm_client = UnifiedLLMClient(self.config)
            self.memory_system = AdvancedMemorySystem(self.config)
            self.cost_monitor = CostMonitor(self.config)
            
            self.initialized = True
            logger.info("Integrated conversation system initialized")
        except Exception as e:
            logger.error(f"Failed to initialize: {e}")
            raise
    
    async def process_conversation(self,
                                 query: str,
                                 project_id: str,
                                 conversation_id: str,
                                 user_id: str,
                                 context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process a conversation turn"""
        if not self.initialized:
            await self.initialize()
        
        start_time = time.time()
        
        try:
            # Search for relevant memories
            memory_results = await self.memory_system.search_memories(
                query=query,
                project_id=project_id,
                limit=3
            )
            
            # Build context from memories
            memory_context = ""
            if memory_results:
                memory_context = "\n\nRelevant memories:\n"
                for memory, score in memory_results:
                    memory_context += f"- {memory.query} -> {memory.response[:100]}...\n"
            
            # Build system prompt
            system_prompt = """You are ADAM (Advanced Data Analytics Model), an AI assistant specializing in software development, data analysis, and problem-solving. You have access to previous conversations and can maintain context across sessions."""
            
            if memory_context:
                system_prompt += memory_context
            
            # Get model from context or use default
            model = context.get('model', 'automatic') if context else 'automatic'
            
            # Add model to context for LLM client
            if context is None:
                context = {}
            context['model'] = model
            
            # Generate response using the LLM client
            response = await self.llm_client.complete(
                prompt=query,
                model=model,
                system_prompt=system_prompt,
                temperature=0.7,
                max_tokens=4096
            )
            
            # Track cost
            cost = 0.0
            if self.cost_monitor and hasattr(response, 'cost'):
                cost = self.cost_monitor.track_cost(
                    model=response.model,
                    input_tokens=getattr(response, 'total_tokens', 0) - getattr(response, 'completion_tokens', 0),
                    output_tokens=getattr(response, 'completion_tokens', 0)
                )
            
            # Store in memory
            await self.memory_system.store_memory(
                query=query,
                response=response.content,
                project_id=project_id,
                conversation_id=conversation_id,
                confidence=0.9
            )
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            return {
                'response': response.content,
                'model_used': getattr(response, 'model', 'gpt-4o-mini'),
                'input_tokens': getattr(response, 'total_tokens', 0) - getattr(response, 'completion_tokens', 0),
                'output_tokens': getattr(response, 'completion_tokens', 0),
                'cost': cost,
                'processing_time': processing_time,
                'memory_confidence': 0.8 if memory_results else 0.0,
                'complexity': 'simple',
                'memory_found': bool(memory_results),
                'should_store': True,
                'sources': []
            }
            
        except Exception as e:
            logger.error(f"Error processing conversation: {e}")
            return {
                'response': f"I apologize, but I encountered an error: {str(e)}",
                'model_used': 'error',
                'input_tokens': 0,
                'output_tokens': 0,
                'cost': 0.0,
                'processing_time': time.time() - start_time,
                'memory_confidence': 0.0,
                'complexity': 'simple',
                'memory_found': False,
                'should_store': False,
                'sources': []
            }