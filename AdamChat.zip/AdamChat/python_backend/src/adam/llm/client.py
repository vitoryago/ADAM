"""
Simplified LLM Client for ADAM
"""
import os
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
import aiohttp
import json
import logging

logger = logging.getLogger(__name__)

@dataclass
class LLMResponse:
    """Response from LLM"""
    content: str
    model: str
    total_tokens: int = 0
    completion_tokens: int = 0
    cost: float = 0.0

class UnifiedLLMClient:
    """Unified client for multiple LLM providers"""
    
    def __init__(self, config=None):
        self.config = config
        self.openai_api_key = os.getenv('OPENAI_API_KEY')
        self.xai_api_key = os.getenv('XAI_API_KEY')
        self.anthropic_api_key = os.getenv('ANTHROPIC_API_KEY')
        
        # Model pricing (per 1M tokens)
        self.pricing = {
            'gpt-4o-mini': {'input': 0.15, 'output': 0.60},
            'gpt-4o': {'input': 2.50, 'output': 10.00},
            'grok-3-mini': {'input': 0.15, 'output': 0.60},
            'grok-4': {'input': 2.00, 'output': 8.00}
        }
    
    async def complete(self,
                      prompt: str,
                      model: str = "automatic",
                      system_prompt: Optional[str] = None,
                      temperature: float = 0.7,
                      max_tokens: int = 4096) -> LLMResponse:
        """Complete a prompt using the specified model"""
        
        # Handle automatic model selection
        if model == "automatic":
            model = self._select_model(prompt)
        
        # Route to appropriate provider
        if model.startswith('gpt'):
            return await self._call_openai(prompt, model, system_prompt, temperature, max_tokens)
        elif model.startswith('grok'):
            return await self._call_grok(prompt, model, system_prompt, temperature, max_tokens)
        else:
            # Fallback to OpenAI
            return await self._call_openai(prompt, 'gpt-4o-mini', system_prompt, temperature, max_tokens)
    
    def _select_model(self, prompt: str) -> str:
        """Select model based on query complexity"""
        # Simple heuristic based on prompt length and keywords
        prompt_lower = prompt.lower()
        
        # Complex tasks
        if any(keyword in prompt_lower for keyword in ['code', 'implement', 'debug', 'analyze', 'design']):
            return 'gpt-4o-mini'
        
        # Simple questions
        if len(prompt) < 100:
            return 'gpt-4o-mini'
        
        # Default
        return 'gpt-4o-mini'
    
    async def _call_openai(self, 
                          prompt: str,
                          model: str,
                          system_prompt: Optional[str],
                          temperature: float,
                          max_tokens: int) -> LLMResponse:
        """Call OpenAI API"""
        
        if not self.openai_api_key:
            logger.warning("OpenAI API key not found")
            return self._fallback_response(prompt)
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    'https://api.openai.com/v1/chat/completions',
                    headers={
                        'Authorization': f'Bearer {self.openai_api_key}',
                        'Content-Type': 'application/json'
                    },
                    json={
                        'model': model,
                        'messages': messages,
                        'temperature': temperature,
                        'max_tokens': max_tokens
                    }
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        content = data['choices'][0]['message']['content']
                        usage = data.get('usage', {})
                        prompt_tokens = usage.get('prompt_tokens', 0)
                        completion_tokens = usage.get('completion_tokens', 0)
                        total_tokens = usage.get('total_tokens', 0)
                        
                        # Calculate cost
                        cost = self._calculate_cost(model, prompt_tokens, completion_tokens)
                        
                        return LLMResponse(
                            content=content,
                            model=model,
                            total_tokens=total_tokens,
                            completion_tokens=completion_tokens,
                            cost=cost
                        )
                    else:
                        error_text = await response.text()
                        logger.error(f"OpenAI API error: {response.status} - {error_text}")
                        return self._fallback_response(prompt)
                        
        except Exception as e:
            logger.error(f"Error calling OpenAI: {e}")
            return self._fallback_response(prompt)
    
    async def _call_grok(self,
                        prompt: str,
                        model: str,
                        system_prompt: Optional[str],
                        temperature: float,
                        max_tokens: int) -> LLMResponse:
        """Call Grok API"""
        
        if not self.xai_api_key:
            logger.warning("xAI API key not found, falling back to OpenAI")
            return await self._call_openai(prompt, 'gpt-4o-mini', system_prompt, temperature, max_tokens)
        
        # For now, redirect to OpenAI as Grok integration needs the xai-sdk
        return await self._call_openai(prompt, 'gpt-4o-mini', system_prompt, temperature, max_tokens)
    
    def _calculate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost based on tokens"""
        if model not in self.pricing:
            return 0.0
        
        input_cost = (input_tokens / 1_000_000) * self.pricing[model]['input']
        output_cost = (output_tokens / 1_000_000) * self.pricing[model]['output']
        
        return input_cost + output_cost
    
    def _fallback_response(self, prompt: str) -> LLMResponse:
        """Fallback response when no API is available"""
        return LLMResponse(
            content=f"I'm ADAM, your AI assistant. I received your message: '{prompt[:100]}...'. However, I'm currently unable to connect to my language models. Please ensure your API keys are configured.",
            model='fallback',
            total_tokens=len(prompt.split()),
            completion_tokens=50,
            cost=0.0
        )