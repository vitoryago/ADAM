"""
ADAM - Analytics Data Assistant with Memory
Core components for the intelligent assistant system
"""

from .config import ADAMConfig
from .project_manager import ProjectManager
from .memory_system import AdvancedMemorySystem
from .integrated_conversation_system import IntegratedConversationSystem
from .cost_monitor import CostMonitor

__version__ = "3.1.0"

__all__ = [
    'ADAMConfig',
    'ProjectManager',
    'AdvancedMemorySystem',
    'IntegratedConversationSystem',
    'CostMonitor'
]