"""
Configuration module for ADAM
"""
import os
from typing import Dict, Any, Optional

class ADAMConfig:
    """Main configuration class for ADAM"""
    
    def __init__(self):
        # API Keys
        self.openai_api_key = os.getenv('OPENAI_API_KEY')
        self.xai_api_key = os.getenv('XAI_API_KEY')
        self.anthropic_api_key = os.getenv('ANTHROPIC_API_KEY')
        
        # Model configurations
        self.default_model = 'gpt-4o-mini'
        self.model_routing_enabled = True
        
        # Memory configurations
        self.memory_enabled = True
        self.memory_collection = 'adam_memories'
        self.chroma_persist_directory = './chroma_db'
        
        # Cost limits
        self.daily_cost_limit = 1.0
        self.monthly_cost_limit = 30.0
        
        # System configurations
        self.log_level = os.getenv('LOG_LEVEL', 'INFO')
        self.debug_mode = os.getenv('DEBUG', 'false').lower() == 'true'
    
    def get_model_config(self, model_name: str) -> Dict[str, Any]:
        """Get configuration for a specific model"""
        model_configs = {
            'gpt-4o-mini': {
                'max_tokens': 4096,
                'temperature': 0.7,
                'provider': 'openai'
            },
            'gpt-4o': {
                'max_tokens': 4096,
                'temperature': 0.7,
                'provider': 'openai'
            },
            'grok-3-mini': {
                'max_tokens': 4096,
                'temperature': 0.7,
                'provider': 'xai'
            },
            'grok-4': {
                'max_tokens': 8192,
                'temperature': 0.7,
                'provider': 'xai'
            }
        }
        return model_configs.get(model_name, model_configs[self.default_model])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            'default_model': self.default_model,
            'model_routing_enabled': self.model_routing_enabled,
            'memory_enabled': self.memory_enabled,
            'daily_cost_limit': self.daily_cost_limit,
            'monthly_cost_limit': self.monthly_cost_limit,
            'debug_mode': self.debug_mode
        }