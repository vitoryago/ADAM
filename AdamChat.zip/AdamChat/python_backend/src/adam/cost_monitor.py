"""
Cost monitoring module for ADAM
"""
import json
import os
from datetime import datetime, timedelta
from typing import Dict, Any

class CostMonitor:
    """Monitor and track API costs"""
    
    def __init__(self, config=None):
        self.config = config
        self.costs_file = 'costs.json'
        self.costs = self._load_costs()
        
        # Model pricing (per 1M tokens)
        self.pricing = {
            'gpt-4o-mini': {'input': 0.15, 'output': 0.60},
            'gpt-4o': {'input': 2.50, 'output': 10.00},
            'grok-3-mini': {'input': 0.15, 'output': 0.60},
            'grok-4': {'input': 2.00, 'output': 8.00},
            'claude-3-haiku': {'input': 0.25, 'output': 1.25},
            'claude-3-sonnet': {'input': 3.00, 'output': 15.00}
        }
    
    def _load_costs(self) -> Dict[str, Any]:
        """Load costs from file"""
        if os.path.exists(self.costs_file):
            try:
                with open(self.costs_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {'daily': {}, 'monthly': {}}
    
    def _save_costs(self):
        """Save costs to file"""
        try:
            with open(self.costs_file, 'w') as f:
                json.dump(self.costs, f, indent=2)
        except Exception as e:
            print(f"Error saving costs: {e}")
    
    def track_cost(self, model: str, input_tokens: int, output_tokens: int):
        """Track API usage cost"""
        if model not in self.pricing:
            return
        
        # Calculate cost
        input_cost = (input_tokens / 1_000_000) * self.pricing[model]['input']
        output_cost = (output_tokens / 1_000_000) * self.pricing[model]['output']
        total_cost = input_cost + output_cost
        
        # Track daily and monthly
        today = datetime.now().strftime('%Y-%m-%d')
        month = datetime.now().strftime('%Y-%m')
        
        if today not in self.costs['daily']:
            self.costs['daily'][today] = 0
        if month not in self.costs['monthly']:
            self.costs['monthly'][month] = 0
        
        self.costs['daily'][today] += total_cost
        self.costs['monthly'][month] += total_cost
        
        self._save_costs()
        
        return total_cost
    
    def get_current_costs(self) -> Dict[str, float]:
        """Get current daily and monthly costs"""
        today = datetime.now().strftime('%Y-%m-%d')
        month = datetime.now().strftime('%Y-%m')
        
        return {
            'daily_total': self.costs['daily'].get(today, 0),
            'monthly_total': self.costs['monthly'].get(month, 0),
            'daily_limit': getattr(self.config, 'daily_cost_limit', 1.0) if self.config else 1.0,
            'monthly_limit': getattr(self.config, 'monthly_cost_limit', 30.0) if self.config else 30.0
        }
    
    def is_within_limits(self) -> bool:
        """Check if costs are within limits"""
        costs = self.get_current_costs()
        return (costs['daily_total'] < costs['daily_limit'] and 
                costs['monthly_total'] < costs['monthly_limit'])