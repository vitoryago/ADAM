"""
Advanced Memory System for ADAM
Handles memory storage, retrieval, and management
"""
import json
import os
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import uuid
from dataclasses import dataclass, asdict

@dataclass
class Memory:
    """Memory data model"""
    id: str
    content: str
    query: str
    response: str
    timestamp: str
    project_id: str
    conversation_id: Optional[str] = None
    confidence: float = 1.0
    access_count: int = 0
    last_accessed: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

class AdvancedMemorySystem:
    """Advanced memory system with project isolation"""
    
    def __init__(self, config=None):
        self.config = config
        self.memories_dir = 'memories'
        os.makedirs(self.memories_dir, exist_ok=True)
        
    def _get_memory_file(self, project_id: str) -> str:
        """Get memory file path for a project"""
        return os.path.join(self.memories_dir, f"project_{project_id}.json")
    
    def _load_memories(self, project_id: str) -> Dict[str, Memory]:
        """Load memories for a project"""
        memory_file = self._get_memory_file(project_id)
        if os.path.exists(memory_file):
            try:
                with open(memory_file, 'r') as f:
                    data = json.load(f)
                    return {
                        mid: Memory(**mdata)
                        for mid, mdata in data.items()
                    }
            except:
                pass
        return {}
    
    def _save_memories(self, project_id: str, memories: Dict[str, Memory]):
        """Save memories for a project"""
        memory_file = self._get_memory_file(project_id)
        try:
            data = {
                mid: memory.to_dict()
                for mid, memory in memories.items()
            }
            with open(memory_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving memories: {e}")
    
    async def store_memory(self, 
                          query: str,
                          response: str,
                          project_id: str,
                          conversation_id: Optional[str] = None,
                          confidence: float = 1.0,
                          metadata: Optional[Dict[str, Any]] = None) -> Memory:
        """Store a new memory"""
        memories = self._load_memories(project_id)
        
        memory = Memory(
            id=str(uuid.uuid4()),
            content=f"{query}\n---\n{response}",
            query=query,
            response=response,
            timestamp=datetime.now().isoformat(),
            project_id=project_id,
            conversation_id=conversation_id,
            confidence=confidence,
            metadata=metadata or {}
        )
        
        memories[memory.id] = memory
        self._save_memories(project_id, memories)
        
        return memory
    
    async def search_memories(self, 
                            query: str,
                            project_id: str,
                            limit: int = 5) -> List[Tuple[Memory, float]]:
        """Search memories for relevant content"""
        memories = self._load_memories(project_id)
        
        # Simple keyword-based search for now
        results = []
        query_lower = query.lower()
        query_words = set(query_lower.split())
        
        for memory in memories.values():
            # Calculate simple relevance score
            content_lower = memory.content.lower()
            content_words = set(content_lower.split())
            
            # Jaccard similarity
            intersection = query_words.intersection(content_words)
            union = query_words.union(content_words)
            
            if union:
                score = len(intersection) / len(union)
                if score > 0:
                    results.append((memory, score))
                    
                    # Update access count
                    memory.access_count += 1
                    memory.last_accessed = datetime.now().isoformat()
        
        # Sort by score and return top results
        results.sort(key=lambda x: x[1], reverse=True)
        
        # Save updated access counts
        if results:
            self._save_memories(project_id, memories)
        
        return results[:limit]
    
    async def get_memory(self, memory_id: str, project_id: str) -> Optional[Memory]:
        """Get a specific memory"""
        memories = self._load_memories(project_id)
        return memories.get(memory_id)
    
    async def get_recent_memories(self, 
                                project_id: str,
                                limit: int = 10) -> List[Memory]:
        """Get recent memories for a project"""
        memories = self._load_memories(project_id)
        
        # Sort by timestamp
        sorted_memories = sorted(
            memories.values(),
            key=lambda m: m.timestamp,
            reverse=True
        )
        
        return sorted_memories[:limit]
    
    async def clear_project_memories(self, project_id: str):
        """Clear all memories for a project"""
        memory_file = self._get_memory_file(project_id)
        if os.path.exists(memory_file):
            os.remove(memory_file)