import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Send, Bot } from "lucide-react";
import { cn } from "@/lib/utils";
import { CodeDemoButton } from "./code-demo-button";

interface MessageInputProps {
  onSendMessage: (content: string, model?: string) => void;
  disabled?: boolean;
}

export function MessageInput({ onSendMessage, disabled = false }: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [selectedModel, setSelectedModel] = useState("automatic");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = () => {
    const trimmedMessage = message.trim();
    if (trimmedMessage && !disabled) {
      onSendMessage(trimmedMessage, selectedModel);
      setMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = Math.min(textarea.scrollHeight, 128) + "px";
    }
  }, [message]);

  const characterCount = message.length;
  const maxCharacters = 4000;
  const isOverLimit = characterCount > maxCharacters;
  const canSend = message.trim().length > 0 && !disabled && !isOverLimit;

  return (
    <div className="border-t border-border bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="relative">
          <div className="flex items-end space-x-3">
            <div className="flex-1 relative">
              <Textarea
                ref={textareaRef}
                placeholder="Message ADAM..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={disabled}
                className={cn(
                  "min-h-[3rem] max-h-32 px-4 py-3 pr-12 bg-muted border-border rounded-2xl resize-none",
                  "focus:ring-2 focus:ring-adam-primary focus:border-transparent",
                  "placeholder:text-muted-foreground",
                  isOverLimit && "border-destructive focus:ring-destructive"
                )}
                rows={1}
              />
              <Button
                onClick={handleSubmit}
                disabled={!canSend}
                size="icon"
                className={cn(
                  "absolute right-2 bottom-2 w-8 h-8 rounded-full",
                  "bg-adam-primary hover:bg-adam-primary/90",
                  "disabled:bg-muted-foreground disabled:cursor-not-allowed"
                )}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center gap-2">
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="w-[140px] h-8 text-xs">
                  <Bot className="w-3 h-3 mr-1" />
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automatic">Automatic</SelectItem>
                  <SelectItem value="gpt-4o-mini">GPT-4o-mini</SelectItem>
                  <SelectItem value="grok-4">Grok-4</SelectItem>
                  <SelectItem value="grok-3-mini">Grok-3-mini</SelectItem>
                </SelectContent>
              </Select>
              <CodeDemoButton onSendMessage={onSendMessage} />
              <p className="text-xs text-muted-foreground">
                ADAM can make mistakes. Consider checking important information.
              </p>
            </div>
            <div className={cn(
              "flex items-center space-x-2 text-xs",
              isOverLimit ? "text-destructive" : "text-muted-foreground"
            )}>
              <span>{characterCount}</span>
              <span>/</span>
              <span>{maxCharacters}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
