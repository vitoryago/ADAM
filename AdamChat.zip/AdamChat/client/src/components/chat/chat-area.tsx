import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageBubble } from "./message-bubble";
import { MessageInput } from "./message-input";
import { TypingIndicator } from "./typing-indicator";
import { useWebSocket } from "@/hooks/use-websocket";
import { useTheme } from "@/components/theme-provider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Brain, Menu, Moon, Sun } from "lucide-react";
import type { Message, Conversation, Project } from "@shared/schema";

interface ChatAreaProps {
  project: Project;
  conversationId: string | null;
  onConversationCreated: (id: string) => void;
  onToggleSidebar: () => void;
}

export function ChatArea({ project, conversationId, onConversationCreated, onToggleSidebar }: ChatAreaProps) {
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  
  const { isConnected, isTyping, error, sendMessage, onMessage, reconnect } = useWebSocket();

  // Load messages for current conversation
  const { data: conversationMessages = [], isLoading } = useQuery<Message[]>({
    queryKey: ["/api/conversations", conversationId, "messages"],
    enabled: !!conversationId,
  });

  // Update local messages when conversation changes
  useEffect(() => {
    setMessages(conversationMessages);
  }, [conversationMessages]);

  // Listen for new WebSocket messages
  useEffect(() => {
    const unsubscribe = onMessage((newMessage) => {
      setMessages(prev => [...prev, newMessage]);
    });
    return unsubscribe;
  }, [onMessage]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Show connection error toast
  useEffect(() => {
    if (error) {
      toast({
        title: "Connection Error",
        description: error,
        variant: "destructive",
        action: (
          <Button variant="outline" size="sm" onClick={reconnect}>
            Retry
          </Button>
        ),
      });
    }
  }, [error, toast, reconnect]);

  const createConversationMutation = useMutation({
    mutationFn: async (title: string) => {
      const response = await apiRequest("POST", "/api/conversations", {
        title,
        projectId: project.id,
        userId: null,
      });
      return await response.json() as Conversation;
    },
    onSuccess: (conversation) => {
      onConversationCreated(conversation.id);
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project.id, "conversations"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create new conversation.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = async (content: string, model?: string) => {
    if (!isConnected) {
      toast({
        title: "Not Connected",
        description: "Please wait for connection to be established.",
        variant: "destructive",
      });
      return;
    }

    let targetConversationId = conversationId;

    // Create new conversation if needed
    if (!targetConversationId) {
      try {
        const title = content.length > 50 ? content.substring(0, 47) + "..." : content;
        const conversation = await createConversationMutation.mutateAsync(title);
        targetConversationId = conversation.id;
      } catch (error) {
        console.error("Failed to create conversation:", error);
        return;
      }
    }

    // Send message via WebSocket with model preference
    sendMessage(targetConversationId, content, model);
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 border-b border-border bg-background">
        <Button variant="ghost" size="icon" onClick={onToggleSidebar}>
          <Menu className="w-4 h-4" />
        </Button>
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-gradient-to-br from-adam-primary to-emerald-600 rounded-md flex items-center justify-center">
            <Brain className="w-3 h-3 text-white" />
          </div>
          <h1 className="text-lg font-bold">ADAM</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={toggleTheme}>
          {theme === "light" ? (
            <Moon className="w-4 h-4" />
          ) : (
            <Sun className="w-4 h-4" />
          )}
        </Button>
      </div>

      {/* Messages Container */}
      <ScrollArea className="flex-1">
        <div className="max-w-4xl mx-auto px-4 py-8">
          {!conversationId && messages.length === 0 ? (
            // Welcome Screen
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-adam-primary to-emerald-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Welcome to ADAM</h2>
              <p className="text-muted-foreground max-w-md mx-auto">
                Your AI assistant ready to help with questions, analysis, and creative tasks. 
                How can I assist you today?
              </p>
            </div>
          ) : (
            // Messages
            <div className="space-y-6">
              {isLoading ? (
                <div className="space-y-6">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="flex justify-start animate-pulse">
                      <div className="flex items-start space-x-3 max-w-2xl">
                        <div className="w-8 h-8 bg-muted rounded-full" />
                        <div className="bg-muted rounded-2xl rounded-tl-md px-4 py-3 w-64 h-20" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                messages.map((message) => (
                  <MessageBubble key={message.id} message={message} />
                ))
              )}
              
              {isTyping && <TypingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Connection Status */}
      {!isConnected && (
        <div className="px-4 py-2 bg-destructive text-destructive-foreground text-sm text-center">
          Disconnected from server. Attempting to reconnect...
        </div>
      )}

      {/* Message Input */}
      <MessageInput onSendMessage={handleSendMessage} disabled={!isConnected} />
    </div>
  );
}
