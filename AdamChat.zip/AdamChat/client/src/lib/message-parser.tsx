import React from 'react';
import { CodeBlock, InlineCode } from '@/components/ui/code-highlighter';
import { cn } from '@/lib/utils';

export interface ParsedContent {
  type: 'text' | 'code' | 'inline-code' | 'bold' | 'italic' | 'list' | 'link' | 'linebreak';
  content: string;
  language?: string;
  href?: string;
}

// Enhanced message parser that handles multiple markdown elements
export function parseMessageContent(content: string): ParsedContent[] {
  const parts: ParsedContent[] = [];
  let remaining = content;
  
  while (remaining.length > 0) {
    // Check for code blocks first (highest priority)
    const codeBlockMatch = remaining.match(/^```(\w+)?\n([\s\S]*?)```/);
    if (codeBlockMatch) {
      const [fullMatch, language, code] = codeBlockMatch;
      parts.push({
        type: 'code',
        content: code.trim(),
        language: language || undefined
      });
      remaining = remaining.slice(fullMatch.length);
      continue;
    }
    
    // Check for inline code
    const inlineCodeMatch = remaining.match(/^`([^`\n]+)`/);
    if (inlineCodeMatch) {
      const [fullMatch, code] = inlineCodeMatch;
      parts.push({
        type: 'inline-code',
        content: code
      });
      remaining = remaining.slice(fullMatch.length);
      continue;
    }
    
    // Check for bold text
    const boldMatch = remaining.match(/^\*\*(.*?)\*\*/);
    if (boldMatch) {
      const [fullMatch, text] = boldMatch;
      parts.push({
        type: 'bold',
        content: text
      });
      remaining = remaining.slice(fullMatch.length);
      continue;
    }
    
    // Check for italic text
    const italicMatch = remaining.match(/^\*(.*?)\*/);
    if (italicMatch) {
      const [fullMatch, text] = italicMatch;
      parts.push({
        type: 'italic',
        content: text
      });
      remaining = remaining.slice(fullMatch.length);
      continue;
    }
    
    // Check for links
    const linkMatch = remaining.match(/^\[([^\]]+)\]\(([^)]+)\)/);
    if (linkMatch) {
      const [fullMatch, text, href] = linkMatch;
      parts.push({
        type: 'link',
        content: text,
        href: href
      });
      remaining = remaining.slice(fullMatch.length);
      continue;
    }
    
    // Check for list items
    const listMatch = remaining.match(/^[\-\*\+] (.+)(?:\n|$)/);
    if (listMatch) {
      const [fullMatch, text] = listMatch;
      parts.push({
        type: 'list',
        content: text
      });
      remaining = remaining.slice(fullMatch.length);
      continue;
    }
    
    // Check for line breaks
    if (remaining.startsWith('\n')) {
      parts.push({
        type: 'linebreak',
        content: '\n'
      });
      remaining = remaining.slice(1);
      continue;
    }
    
    // Find the next special character or just take the next character
    const nextSpecialIndex = remaining.search(/[`*\[\-\n]/);
    if (nextSpecialIndex === -1) {
      // No more special characters, add the rest as text
      parts.push({
        type: 'text',
        content: remaining
      });
      remaining = '';
    } else if (nextSpecialIndex === 0) {
      // Special character at start but no match found, take one character
      parts.push({
        type: 'text',
        content: remaining[0]
      });
      remaining = remaining.slice(1);
    } else {
      // Add text up to the next special character
      parts.push({
        type: 'text',
        content: remaining.slice(0, nextSpecialIndex)
      });
      remaining = remaining.slice(nextSpecialIndex);
    }
  }
  
  return parts;
}

// Component to render parsed content
interface MessageContentProps {
  content: string;
  className?: string;
}

export function MessageContent({ content, className }: MessageContentProps) {
  const parsedParts = parseMessageContent(content);
  const listItems: React.ReactNode[] = [];
  const elements: React.ReactNode[] = [];
  
  parsedParts.forEach((part, index) => {
    const key = `part-${index}`;
    
    switch (part.type) {
      case 'code':
        // Flush any pending list items
        if (listItems.length > 0) {
          elements.push(
            <ul key={`list-${elements.length}`} className="space-y-1 my-2 ml-4">
              {listItems.map((item, i) => (
                <li key={i} className="flex items-start">
                  <span className="text-muted-foreground mr-2">•</span>
                  {item}
                </li>
              ))}
            </ul>
          );
          listItems.length = 0;
        }
        elements.push(
          <CodeBlock 
            key={key}
            code={part.content} 
            language={part.language}
          />
        );
        break;
        
      case 'inline-code':
        elements.push(
          <InlineCode key={key}>
            {part.content}
          </InlineCode>
        );
        break;
        
      case 'bold':
        elements.push(
          <strong key={key} className="font-semibold">
            {part.content}
          </strong>
        );
        break;
        
      case 'italic':
        elements.push(
          <em key={key} className="italic">
            {part.content}
          </em>
        );
        break;
        
      case 'link':
        elements.push(
          <a 
            key={key}
            href={part.href}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 dark:text-blue-400 hover:underline"
          >
            {part.content}
          </a>
        );
        break;
        
      case 'list':
        listItems.push(
          <span key={key}>{part.content}</span>
        );
        break;
        
      case 'linebreak':
        // Flush any pending list items
        if (listItems.length > 0) {
          elements.push(
            <ul key={`list-${elements.length}`} className="space-y-1 my-2 ml-4">
              {listItems.map((item, i) => (
                <li key={i} className="flex items-start">
                  <span className="text-muted-foreground mr-2">•</span>
                  {item}
                </li>
              ))}
            </ul>
          );
          listItems.length = 0;
        }
        elements.push(<br key={key} />);
        break;
        
      case 'text':
        elements.push(part.content);
        break;
    }
  });
  
  // Flush any remaining list items
  if (listItems.length > 0) {
    elements.push(
      <ul key={`list-${elements.length}`} className="space-y-1 my-2 ml-4">
        {listItems.map((item, i) => (
          <li key={i} className="flex items-start">
            <span className="text-muted-foreground mr-2">•</span>
            {item}
          </li>
        ))}
      </ul>
    );
  }
  
  return (
    <div className={cn("break-words overflow-wrap-anywhere", className)}>
      {elements}
    </div>
  );
}